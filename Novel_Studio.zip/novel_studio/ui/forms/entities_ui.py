# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'entities.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit,
    QPushButton, QSizePolicy, QVBoxLayout, QWidget)

class Ui_EntitiesPage(object):
    def setupUi(self, EntitiesPage):
        if not EntitiesPage.objectName():
            EntitiesPage.setObjectName(u"EntitiesPage")
        self.l = QHBoxLayout(EntitiesPage)
        self.l.setObjectName(u"l")
        self.left = QVBoxLayout()
        self.left.setObjectName(u"left")
        self.catLbl = QLabel(EntitiesPage)
        self.catLbl.setObjectName(u"catLbl")

        self.left.addWidget(self.catLbl)

        self.catCombo = QComboBox(EntitiesPage)
        self.catCombo.setObjectName(u"catCombo")

        self.left.addWidget(self.catCombo)

        self.entryList = QListWidget(EntitiesPage)
        self.entryList.setObjectName(u"entryList")

        self.left.addWidget(self.entryList)

        self.addRow = QHBoxLayout()
        self.addRow.setObjectName(u"addRow")
        self.addBtn = QPushButton(EntitiesPage)
        self.addBtn.setObjectName(u"addBtn")

        self.addRow.addWidget(self.addBtn)

        self.delBtn = QPushButton(EntitiesPage)
        self.delBtn.setObjectName(u"delBtn")

        self.addRow.addWidget(self.delBtn)


        self.left.addLayout(self.addRow)


        self.l.addLayout(self.left)

        self.right = QVBoxLayout()
        self.right.setObjectName(u"right")
        self.head = QHBoxLayout()
        self.head.setObjectName(u"head")
        self.nameLbl = QLabel(EntitiesPage)
        self.nameLbl.setObjectName(u"nameLbl")

        self.head.addWidget(self.nameLbl)

        self.nameEdit = QLineEdit(EntitiesPage)
        self.nameEdit.setObjectName(u"nameEdit")

        self.head.addWidget(self.nameEdit)

        self.generateBtn = QPushButton(EntitiesPage)
        self.generateBtn.setObjectName(u"generateBtn")

        self.head.addWidget(self.generateBtn)

        self.saveBtn = QPushButton(EntitiesPage)
        self.saveBtn.setObjectName(u"saveBtn")

        self.head.addWidget(self.saveBtn)


        self.right.addLayout(self.head)

        self.detail = QPlainTextEdit(EntitiesPage)
        self.detail.setObjectName(u"detail")

        self.right.addWidget(self.detail)


        self.l.addLayout(self.right)


        self.retranslateUi(EntitiesPage)

        QMetaObject.connectSlotsByName(EntitiesPage)
    # setupUi

    def retranslateUi(self, EntitiesPage):
        self.catLbl.setText(QCoreApplication.translate("EntitiesPage", u"\ubd84\ub958", None))
        self.addBtn.setText(QCoreApplication.translate("EntitiesPage", u"+ \ucd94\uac00", None))
        self.delBtn.setText(QCoreApplication.translate("EntitiesPage", u"\uc0ad\uc81c", None))
        self.nameLbl.setText(QCoreApplication.translate("EntitiesPage", u"\uc774\ub984/\ucf54\ub4dc", None))
        self.generateBtn.setText(QCoreApplication.translate("EntitiesPage", u"AI\ub85c \uc0dd\uc131/\ubcf4\uc644", None))
        self.saveBtn.setText(QCoreApplication.translate("EntitiesPage", u"\uc800\uc7a5", None))
        pass
    # retranslateUi

